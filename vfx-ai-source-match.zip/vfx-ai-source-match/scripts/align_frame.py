#!/usr/bin/env python3
"""Align one corresponding frame pair using SIFT/RANSAC. Requires OpenCV + NumPy."""
import argparse
import json
from pathlib import Path
import sys
import cv2
import numpy as np


def read_image(path):
    value = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if value is None or value.dtype != np.uint8 or value.ndim != 3 or value.shape[2] != 3:
        raise ValueError('Use 8-bit three-channel analysis images: ' + str(path))
    return value


def read_mask(path, shape):
    if not path:
        return None
    value = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if value is None or value.shape != shape:
        raise ValueError('Mask must match its image dimensions')
    return np.where(value > 0, 255, 0).astype(np.uint8)


def align(reference, moving, model='affine', reference_mask=None, moving_mask=None):
    detector = cv2.SIFT_create(nfeatures=6000)
    kr, dr = detector.detectAndCompute(cv2.cvtColor(reference, cv2.COLOR_BGR2GRAY), reference_mask)
    km, dm = detector.detectAndCompute(cv2.cvtColor(moving, cv2.COLOR_BGR2GRAY), moving_mask)
    if dr is None or dm is None or len(dr) < 8 or len(dm) < 8:
        raise ValueError('Insufficient common texture; do not invent a transform')
    pairs = cv2.BFMatcher().knnMatch(dm, dr, k=2)
    matches = [pair[0] for pair in pairs if len(pair) == 2 and pair[0].distance < .7*pair[1].distance]
    # Prevent repeated moving features from all selecting the same reference point.
    unique = {}
    for match in sorted(matches, key=lambda v: v.distance):
        unique.setdefault(match.trainIdx, match)
    matches = list(unique.values())
    if len(matches) < 8:
        raise ValueError('Fewer than eight unambiguous correspondences')
    src = np.float32([km[v.queryIdx].pt for v in matches])
    dst = np.float32([kr[v.trainIdx].pt for v in matches])
    cv2.setRNGSeed(0)
    if model == 'affine':
        affine, inliers = cv2.estimateAffine2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=2.)
        matrix = np.vstack([affine, [0, 0, 1]]) if affine is not None else None
    else:
        matrix, inliers = cv2.findHomography(src, dst, cv2.RANSAC, 2.)
    if matrix is None or not np.isfinite(matrix).all() or abs(np.linalg.det(matrix)) < 1e-10:
        raise ValueError('Degenerate transform')
    selected = inliers.ravel().astype(bool)
    if selected.sum() < 8 or selected.mean() < .4:
        raise ValueError('Insufficient RANSAC support')
    predicted = cv2.perspectiveTransform(src[:, None], matrix)[:, 0]
    error = np.linalg.norm(predicted[selected]-dst[selected], axis=1)
    h, w = reference.shape[:2]
    coverage = float(cv2.contourArea(cv2.convexHull(dst[selected]))/(w*h))
    if coverage < .01:
        raise ValueError('Inliers are too clustered to support frame alignment')
    warped = cv2.warpPerspective(moving, matrix, (w, h))
    valid = cv2.warpPerspective(np.full(moving.shape[:2], 255, np.uint8), matrix, (w, h), flags=cv2.INTER_NEAREST)
    diagnostics = dict(model=model, moving_to_reference=matrix.tolist(), matches=len(matches),
                       inliers=int(selected.sum()), median_error_px=float(np.median(error)),
                       max_error_px=float(error.max()), reference_coverage=coverage,
                       note='Frame-pair planar alignment only. Inspect overlays; no timing or deformation repair.')
    return warped, valid, diagnostics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('reference', 'moving', 'output', 'transform', 'valid'):
        parser.add_argument('--'+name, required=True)
    parser.add_argument('--reference-mask')
    parser.add_argument('--moving-mask')
    parser.add_argument('--model', choices=['affine', 'homography'], default='affine')
    args = parser.parse_args()
    try:
        paths = [Path(args.output), Path(args.valid), Path(args.transform)]
        if len({p.resolve() for p in paths}) != 3 or any(p.exists() for p in paths):
            raise ValueError('Use three distinct new output paths')
        if any(p.suffix.lower() != '.png' for p in paths[:2]):
            raise ValueError('Image outputs must be lossless PNG')
        ref, mov = read_image(args.reference), read_image(args.moving)
        result, valid, report = align(ref, mov, args.model,
                                    read_mask(args.reference_mask, ref.shape[:2]),
                                    read_mask(args.moving_mask, mov.shape[:2]))
        for path, value in zip(paths[:2], (result, valid)):
            if not cv2.imwrite(str(path), value):
                raise ValueError('Image write failed: ' + str(path))
        paths[2].write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
        print(json.dumps(report))
        return 0
    except (ValueError, OSError, cv2.error) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
