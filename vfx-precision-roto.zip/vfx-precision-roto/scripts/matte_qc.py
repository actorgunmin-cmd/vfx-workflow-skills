#!/usr/bin/env python3
"""Report alpha coverage, soft edges and temporal changes. These are QC flags, not accuracy scores."""
import argparse
import json
from pathlib import Path
import sys
import cv2
import numpy as np


def inspect(directory):
    paths = sorted(Path(directory).glob('*.png'))
    if not paths:
        raise ValueError('No PNG alpha frames; use zero-padded filenames')
    previous = None
    rows = []
    for path in paths:
        value = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
        if value is None or value.ndim != 2 or value.dtype not in (np.uint8, np.uint16):
            raise ValueError('Expected grayscale 8/16-bit alpha: ' + str(path))
        alpha = value.astype(np.float32)/np.iinfo(value.dtype).max
        if previous is not None and previous.shape != alpha.shape:
            raise ValueError('Frame dimensions changed')
        row = dict(file=path.name, coverage=float(alpha.mean()),
                   soft_fraction=float(np.mean((alpha > 0) & (alpha < 1))),
                   empty=bool(not np.any(alpha)), full=bool(np.all(alpha == 1)))
        if previous is not None:
            row['mean_absolute_alpha_change'] = float(np.mean(np.abs(alpha-previous)))
        rows.append(row)
        previous = alpha
    return dict(frame_count=len(rows), width=previous.shape[1], height=previous.shape[0], frames=rows,
                limits='Large change may be valid motion or a cut; binary alpha may be correct for hard objects. '
                       'No ground-truth accuracy, identity, missing-frame or foreground RGB assessment.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        target = Path(args.output)
        if target.exists():
            raise ValueError('Choose a new output path')
        data = inspect(args.directory)
        target.write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
        print(f"Inspected {data['frame_count']} alpha frames; no quality guarantee inferred.")
        return 0
    except (ValueError, OSError, cv2.error) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
