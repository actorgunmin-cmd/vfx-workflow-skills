#!/usr/bin/env python3
"""PCM WAV to per-video-frame energy/onset CSV. No stem separation or learned beat tracking."""
import argparse
import csv
from fractions import Fraction
import math
import sys
import wave


def compute(path, fps):
    rate = Fraction(str(fps))
    if rate <= 0 or rate > 1000:
        raise ValueError('fps must be in (0,1000]')
    with wave.open(str(path), 'rb') as wav:
        if wav.getcomptype() != 'NONE' or wav.getsampwidth() not in (1, 2, 3, 4):
            raise ValueError('Use uncompressed integer PCM WAV, 8/16/24/32 bit')
        sample_rate, channels, width = wav.getframerate(), wav.getnchannels(), wav.getsampwidth()
        total = wav.getnframes()
        count = math.ceil(Fraction(total, sample_rate)*rate)
        rows = []
        previous = 0.0
        for frame in range(count):
            start = int(Fraction(frame*sample_rate, 1)/rate)
            end = min(total, int(Fraction((frame+1)*sample_rate,1)/rate))
            raw = wav.readframes(end-start)
            # Mean channel energy avoids phase cancellation from L+R downmix.
            value_sum, sample_count = 0.0, 0
            for offset in range(0, len(raw), width):
                chunk = raw[offset:offset+width]
                if len(chunk) != width:
                    raise ValueError('Truncated PCM sample')
                sample = (chunk[0]-128)/128 if width == 1 else int.from_bytes(chunk,'little',signed=True)/float(1 << (8*width-1))
                value_sum += sample*sample
                sample_count += 1
            if sample_count != (end-start)*channels:
                raise ValueError('Truncated WAV frames')
            rms = math.sqrt(value_sum/sample_count) if sample_count else 0.0
            onset = max(0.0, rms-previous)
            rows.append({'frame':frame,'time_seconds':float(Fraction(frame,1)/rate),
                         'rms':rms,'onset':onset})
            previous = rms
        peak = max((r['rms'] for r in rows), default=0.0)
        onset_peak = max((r['onset'] for r in rows), default=0.0)
        for row in rows:
            row['energy_0_1'] = row['rms']/peak if peak else 0.0
            row['onset_0_1'] = row['onset']/onset_peak if onset_peak else 0.0
        return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wav', required=True)
    parser.add_argument('--fps', default='24', help='Number or rational, e.g. 30000/1001')
    parser.add_argument('--output', required=True, help='New CSV path; frame numbering starts at zero')
    args = parser.parse_args()
    try:
        rows = compute(args.wav, args.fps)
        with open(args.output,'x',newline='',encoding='utf-8') as stream:
            writer = csv.DictWriter(stream,fieldnames=['frame','time_seconds','rms','onset','energy_0_1','onset_0_1'])
            writer.writeheader()
            writer.writerows(rows)
        print(f'Wrote {len(rows)} frame bins. RMS/onset only; no drum extraction or tempo estimate.')
        return 0
    except (OSError, ValueError, wave.Error, ZeroDivisionError) as error:
        print(str(error),file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
