#!/usr/bin/env python3
"""Convert COLMAP images.txt poses to explicit camera-to-world JSON, using stdlib."""
import argparse
import json
import math
import sys


def quaternion_matrix(q):
    length = math.sqrt(sum(x*x for x in q))
    if not math.isfinite(length) or length < 1e-12:
        raise ValueError('Invalid COLMAP quaternion')
    w, x, y, z = [a/length for a in q]
    return [[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
            [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
            [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]]


def convert_pose(q, t):
    if not all(math.isfinite(v) for v in t):
        raise ValueError('Non-finite translation')
    rotation = quaternion_matrix(q)
    rt = [[rotation[j][i] for j in range(3)] for i in range(3)]
    center = [-sum(rt[i][j]*t[j] for j in range(3)) for i in range(3)]
    c2w = [rt[i]+[center[i]] for i in range(3)] + [[0, 0, 0, 1]]
    # cv camera: +X right, +Y down, +Z forward.
    # Blender/OpenGL camera: +X right, +Y up, -Z forward.
    # Keep the COLMAP world fixed and change the camera-local basis only.
    gl = [[c2w[i][j]*([1, -1, -1, 1][j]) for j in range(4)] for i in range(4)]
    return {'camera_center_colmap_world': center,
            'camera_to_world_cv': c2w, 'camera_to_world_gl': gl}


def parse_images(path):
    images = []
    expecting_pose = True
    seen = set()
    with open(path, encoding='utf-8') as stream:
        for number, raw in enumerate(stream, 1):
            line = raw.strip()
            if line.startswith('#'):
                continue
            if not expecting_pose:
                # The POINTS2D record may be empty and still consumes a line.
                fields = line.split()
                if len(fields) % 3:
                    raise ValueError(f'Invalid POINTS2D record at line {number}')
                for i in range(0, len(fields), 3):
                    if not all(math.isfinite(float(v)) for v in fields[i:i+2]):
                        raise ValueError(f'Non-finite POINTS2D at line {number}')
                    int(fields[i+2])
                expecting_pose = True
                continue
            if not line:
                continue
            fields = line.split(maxsplit=9)
            if len(fields) != 10:
                raise ValueError(f'Invalid image pose at line {number}')
            image_id, camera_id = int(fields[0]), int(fields[8])
            if image_id in seen:
                raise ValueError('Duplicate IMAGE_ID: ' + str(image_id))
            seen.add(image_id)
            q = [float(v) for v in fields[1:5]]
            t = [float(v) for v in fields[5:8]]
            images.append(dict(image_id=image_id, camera_id=camera_id, name=fields[9],
                               world_to_camera_qwxyz=q, world_to_camera_t=t, **convert_pose(q,t)))
            expecting_pose = False
    if not expecting_pose:
        raise ValueError('Missing final POINTS2D line; even an empty record needs a newline')
    if not images:
        raise ValueError('No image poses found')
    return images


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--images', required=True, help='COLMAP text images.txt')
    parser.add_argument('--output', required=True, help='New JSON path')
    args = parser.parse_args()
    try:
        poses = parse_images(args.images)
        data = {'convention': 'Matrices are row-major; multiply column vectors. World is unchanged COLMAP world.',
                'scale': 'arbitrary SfM units unless calibrated separately',
                'intrinsics': 'Not included. Read cameras.txt using camera_id; retain its lens model.',
                'timing': 'Not inferred from IMAGE_ID. Use frame filename-to-source PTS mapping.',
                'images': poses}
        with open(args.output, 'x', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write('\n')
        print(f'Converted {len(poses)} camera poses; no world alignment or intrinsics inference performed.')
        return 0
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
