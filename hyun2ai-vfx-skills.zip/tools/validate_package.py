import csv
import hashlib
import importlib.util
import json
import math
import os
import re
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import wave
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
import yaml


def add_to_zip(archive, path, arcname):
    info = zipfile.ZipInfo(str(arcname), date_time=(2026, 11, 7, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, path.read_bytes())


def validate_skill(folder):
    content = (folder/'SKILL.md').read_text(encoding='utf-8')
    match = re.match(r'^---\n(.*?)\n---\n', content, re.S)
    if not match:
        return False, 'Missing frontmatter'
    data = yaml.safe_load(match[1])
    valid = (isinstance(data, dict) and data.get('name') == folder.name
             and re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', folder.name)
             and len(folder.name) < 64 and isinstance(data.get('description'), str)
             and 0 < len(data['description']) <= 1024 and '[TODO:' not in content)
    return bool(valid), 'Frontmatter/name/description check'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def main():
    out = ROOT if (ROOT/'skills').is_dir() else ROOT/'outputs'
    folders = sorted((out/'skills').iterdir())
    assert len(folders) == 30
    results = []
    for folder in folders:
        valid, message = validate_skill(folder)
        assert valid, (folder.name, message)
        meta = yaml.safe_load((folder/'agents'/'openai.yaml').read_text())
        interface = meta['interface']
        assert '$'+folder.name in interface['default_prompt']
        assert 25 <= len(interface['short_description']) <= 64
        assert len((folder/'SKILL.md').read_text()) > 1000
        for script in folder.glob('scripts/*.py'):
            compile(script.read_text(), str(script), 'exec')
        for relative in re.findall(r'scripts/[A-Za-z0-9_/-]+\.py', (folder/'SKILL.md').read_text()):
            assert (folder/relative).is_file(), (folder.name, relative)
        results.append({'name':folder.name,'structure':'passed'})

    colmap_path = out/'skills'/'colmap-vfx'/'scripts'/'colmap_pose.py'
    audio_path = out/'skills'/'vfx-audio-reactive'/'scripts'/'audio_envelope.py'
    inspect_path = out/'skills'/'vfx-shot-pipeline'/'scripts'/'inspect_plate.py'
    cam = module('colmap_pose', colmap_path)
    audio = module('audio_envelope', audio_path)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    tests = []
    with tempfile.TemporaryDirectory() as directory:
        temp = Path(directory)
        q = [math.sqrt(.5),0,0,math.sqrt(.5)]
        pose = cam.convert_pose(q,[1,2,3])
        expected = [-2,1,-3]
        assert all(abs(a-b)<1e-9 for a,b in zip(pose['camera_center_colmap_world'], expected))
        # A point five units along Blender's -Z lies five units in front of the CV camera.
        point = [sum(pose['camera_to_world_gl'][i][j]*[0,0,-5,1][j] for j in range(4)) for i in range(3)]
        rotation = cam.quaternion_matrix(q)
        reprojected = [sum(rotation[i][j]*point[j] for j in range(3))+[1,2,3][i] for i in range(3)]
        assert all(abs(a-b)<1e-9 for a,b in zip(reprojected,[0,0,5]))
        tests.append('rotated translated camera: projection and GL basis agree')

        image_text = temp/'images.txt'
        image_text.write_text('# fixture\n17 1 0 0 0 1 2 3 5 frame 0001.png\n\n91 1 0 0 0 0 0 0 5 frame0002.png\n10 20 -1\n')
        parsed = cam.parse_images(image_text)
        assert [p['image_id'] for p in parsed] == [17,91]
        assert parsed[0]['name'] == 'frame 0001.png'
        subprocess.run([sys.executable,str(colmap_path),'--images',str(image_text),'--output',str(temp/'poses.json')],check=True,capture_output=True,env=env)
        assert len(json.loads((temp/'poses.json').read_text())['images']) == 2
        tests.append('COLMAP text: empty observations, noncontiguous IDs, filenames, CLI JSON')
        image_text.write_text('17 0 0 0 0 1 2 3 5 x.png\n\n')
        rejected = subprocess.run([sys.executable,str(colmap_path),'--images',str(image_text),'--output',str(temp/'bad.json')],capture_output=True,env=env)
        assert rejected.returncode != 0 and not (temp/'bad.json').exists()
        tests.append('invalid quaternion rejected without writing a result')

        silence = temp/'silence.wav'
        with wave.open(str(silence),'wb') as stream:
            stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(8000)
            stream.writeframes(bytes(16000))
        silent = audio.compute(silence,'30000/1001')
        assert len(silent)==30 and all(r['energy_0_1']==0 and r['onset_0_1']==0 for r in silent)
        assert abs(silent[1]['time_seconds']-1001/30000)<1e-12
        tests.append('silence has no false onsets; rational frame timing retained')
        stereo = temp/'stereo.wav'
        with wave.open(str(stereo),'wb') as stream:
            stream.setnchannels(2);stream.setsampwidth(2);stream.setframerate(8000)
            stream.writeframes(b''.join(struct.pack('<hh',s,-s) for s in ([0]*4000+[16384]*4000)))
        values = audio.compute(stereo,'10')
        assert all(row['rms']==0 for row in values[:5])
        assert all(abs(row['rms']-.5)<1e-12 for row in values[5:])
        assert values[5]['onset_0_1']==1 and all(row['onset_0_1']==0 for row in values[6:])
        subprocess.run([sys.executable,str(audio_path),'--wav',str(stereo),'--fps','10','--output',str(temp/'audio.csv')],check=True,capture_output=True,env=env)
        assert len(list(csv.DictReader((temp/'audio.csv').open())))==10
        tests.append('opposite-phase stereo energy preserved; transition and CSV CLI verified')

        fixture = temp/'plate.bin';fixture.write_bytes(b'fixture')
        missing = subprocess.run([sys.executable,str(inspect_path),str(temp/'missing.mov')],capture_output=True,env=env)
        assert missing.returncode==1
        probe_env=dict(env,PATH=str(temp))
        missing_probe=subprocess.run([sys.executable,str(inspect_path),str(fixture)],capture_output=True,text=True,env=probe_env)
        assert missing_probe.returncode==2 and json.loads(missing_probe.stdout)['status']=='ffprobe_missing'
        tests.append('media helper distinguishes missing input and missing ffprobe')

        import cv2
        import numpy as np
        aligner = module('align_frame', out/'skills/vfx-ai-source-match/scripts/align_frame.py')
        color = module('match_color', out/'skills/vfx-source-color-match/scripts/match_color.py')
        comp = module('composite_frame', out/'skills/vfx-original-restore/scripts/composite_frame.py')
        qc = module('matte_qc', out/'skills/vfx-precision-roto/scripts/matte_qc.py')
        rng = np.random.default_rng(21)
        ref = cv2.GaussianBlur(rng.integers(0, 256, (360, 480, 3), dtype=np.uint8), (3, 3), 0)
        matrix = cv2.getRotationMatrix2D((240, 180), 1.5, 1.01)
        matrix[:, 2] += [7, -4]
        mov = cv2.warpAffine(ref, matrix, (480, 360))
        result, valid, report = aligner.align(ref, mov)
        expected = np.linalg.inv(np.vstack([matrix, [0, 0, 1]]))
        probes = np.float32([[[40, 40]], [[430, 40]], [[40, 310]], [[430, 310]]])
        measured = cv2.perspectiveTransform(probes, np.array(report['moving_to_reference']))
        truth = cv2.perspectiveTransform(probes, expected)
        assert np.max(np.linalg.norm(measured-truth, axis=2)) < .7
        assert valid.shape == ref.shape[:2] and np.any(valid == 0)
        try:
            aligner.align(np.zeros_like(ref), np.zeros_like(ref))
            raise AssertionError('Textureless alignment accepted')
        except ValueError:
            pass
        tests.append('affine camera perturbation recovered within 0.7 px; textureless frames rejected')

        samples = rng.uniform(.15, .7, (10000, 3)).astype(np.float32)
        gain = np.array([1.1, .9, 1.05])
        offset = np.array([.02, .03, -.01])
        reference_samples = samples*gain+offset
        grade = color.fit(reference_samples, samples)
        matched, clipped = color.apply(samples, grade)
        assert np.max(np.abs(matched-reference_samples)) < 1e-5 and clipped == 0
        other = samples[::-1]*.9
        assert np.max(np.abs(color.apply(other, grade)[0]-(other*gain+offset))) < 1e-5
        try:
            color.fit(np.ones((100, 3)), np.ones((100, 3)))
            raise AssertionError('Flat patch accepted')
        except ValueError:
            pass
        tests.append('known color gain/offset recovered; fixed shot grade reusable; flat patches rejected')

        fg = np.ones((2, 3, 3), np.float32)
        bg = np.zeros_like(fg)
        alpha = np.tile(np.array([0., .5, 1.], np.float32), (2, 1))
        composed = comp.composite(fg, bg, alpha)
        assert np.allclose(composed[:, 0], 0) and np.allclose(composed[:, 2], 1)
        assert np.allclose(composed[:, 1], .73535698, atol=1e-6)
        tests.append('linear-light over retains alpha endpoints and correct 50% sRGB luminance')

        matte_dir = temp/'alpha'
        matte_dir.mkdir()
        cv2.imwrite(str(matte_dir/'0000.png'), np.zeros((10, 10), np.uint16))
        cv2.imwrite(str(matte_dir/'0001.png'), np.full((10, 10), 32768, np.uint16))
        data = qc.inspect(matte_dir)
        assert data['frame_count'] == 2 and data['frames'][0]['empty']
        assert data['frames'][1]['soft_fraction'] == 1
        assert abs(data['frames'][1]['mean_absolute_alpha_change']-.5) < 2e-5
        tests.append('16-bit alpha QC distinguishes empty and soft mattes and records temporal change')

        ref_path, mov_path = temp/'ref.png', temp/'mov.png'
        cv2.imwrite(str(ref_path), ref); cv2.imwrite(str(mov_path), mov)
        align_path = out/'skills/vfx-ai-source-match/scripts/align_frame.py'
        alignment_cmd = [sys.executable, str(align_path), '--reference', str(ref_path), '--moving', str(mov_path),
                         '--output', str(temp/'aligned.png'), '--valid', str(temp/'valid.png'),
                         '--transform', str(temp/'transform.json')]
        subprocess.run(alignment_cmd, check=True, capture_output=True, env=env)
        assert subprocess.run(alignment_cmd, capture_output=True, env=env).returncode == 1
        grade_image = np.round(samples[:10000].reshape(100, 100, 3)*65535).astype(np.uint16)
        reference_image = np.round(reference_samples.reshape(100, 100, 3)*65535).astype(np.uint16)
        cv2.imwrite(str(temp/'color.png'), grade_image)
        cv2.imwrite(str(temp/'color-ref.png'), reference_image)
        cv2.imwrite(str(temp/'mask.png'), np.full((100, 100), 255, np.uint8))
        color_path = out/'skills/vfx-source-color-match/scripts/match_color.py'
        color_cmd = [sys.executable, str(color_path), '--moving', str(temp/'color.png'),
                     '--output', str(temp/'matched.png'), '--reference', str(temp/'color-ref.png'),
                     '--reference-mask', str(temp/'mask.png'), '--moving-mask', str(temp/'mask.png'),
                     '--fit', str(temp/'grade.json')]
        subprocess.run(color_cmd, check=True, capture_output=True, env=env)
        assert cv2.imread(str(temp/'matched.png'), -1).dtype == np.uint16
        subprocess.run([sys.executable, str(color_path), '--moving', str(temp/'color.png'),
                        '--output', str(temp/'matched2.png'), '--apply', str(temp/'grade.json')],
                       check=True, capture_output=True, env=env)
        cv2.imwrite(str(temp/'fg.png'), np.full((10, 10, 3), 255, np.uint8))
        cv2.imwrite(str(temp/'bg.png'), np.zeros((10, 10, 3), np.uint8))
        subprocess.run([sys.executable, str(out/'skills/vfx-original-restore/scripts/composite_frame.py'),
                        '--foreground', str(temp/'fg.png'), '--background', str(temp/'bg.png'),
                        '--alpha', str(matte_dir/'0001.png'), '--output', str(temp/'comp.png')],
                       check=True, capture_output=True, env=env)
        subprocess.run([sys.executable, str(out/'skills/vfx-precision-roto/scripts/matte_qc.py'),
                        str(matte_dir), '--output', str(temp/'qc.json')], check=True, capture_output=True, env=env)
        tests.append('four added CLIs write readable outputs; alignment refuses overwrite')

    manifest=json.loads((out/'review-manifest.json').read_text())
    assert len(manifest['posts'])==33 and len({p['id'] for p in manifest['posts']})==33
    names={f.name for f in folders}
    assert all(name in names for post in manifest['posts'] for name in post['skills'])
    for folder in folders:
        for path in folder.rglob('*'):
            if path.is_file() and path.suffix in {'.md','.yaml','.py'}:
                assert path.stat().st_size>0

    validation={'skill_count':len(folders),'public_post_skills':26,'user_requested_skills':4,
                'structures':results,'helper_tests':tests,
                'status':'passed','render_engines_tested':False,
                'test_environment':{'python':sys.version.split()[0],'numpy':np.__version__,'opencv':cv2.__version__},
                'limits':['No original creator skill files were available.',
                          'No production plate or end-to-end COLMAP/Blender/AE/FFmpeg/model execution was tested.',
                          'MatAnyone/MatAnyone 2 GPU inference was not run; alpha QC does not measure ground-truth quality.',
                          'Alignment/color/compositing helpers tested on synthetic stills, not a production video sequence.',
                          'Workflow instructions require installed tools/models or connected services.']}
    (out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
    # Independent ZIP for every skill; full archive uses project-discovery layout.
    for folder in folders:
        with zipfile.ZipFile(out/'individual'/(folder.name+'.zip'),'w',zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(folder.rglob('*')):
                if path.is_file() and '__pycache__' not in path.parts:
                    add_to_zip(archive,path,Path(folder.name)/path.relative_to(folder))
    with zipfile.ZipFile(out/'hyun2ai-vfx-skills.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for folder in folders:
            for path in sorted(folder.rglob('*')):
                if path.is_file() and '__pycache__' not in path.parts:
                    add_to_zip(archive,path,Path('.agents/skills')/folder.name/path.relative_to(folder))
        for name in ['README.md','THIRD_PARTY_NOTICES.md','REVIEW.md','index.html','review-manifest.json','validation.json','requirements-dev.txt']:
            add_to_zip(archive,out/name,name)
        for path in sorted((out/'tools').glob('*.py')):
            add_to_zip(archive,path,Path('tools')/path.name)
        for path in sorted((out/'individual').glob('*.zip')):
            add_to_zip(archive,path,Path('individual')/path.name)
        # index links resolve to both human-friendly skill folders and install layout.
        for folder in folders:
            for path in sorted(folder.rglob('*')):
                if path.is_file() and '__pycache__' not in path.parts:
                    add_to_zip(archive,path,Path('skills')/folder.name/path.relative_to(folder))
    for archive_path in [out/'hyun2ai-vfx-skills.zip',*sorted((out/'individual').glob('*.zip'))]:
        with zipfile.ZipFile(archive_path) as archive:
            assert archive.testzip() is None
            assert all(not n.startswith('/') and '..' not in Path(n).parts for n in archive.namelist())
            assert len(archive.namelist()) == len(set(archive.namelist()))
    sums=[]
    for path in [out/'hyun2ai-vfx-skills.zip',*sorted((out/'individual').glob('*.zip'))]:
        sums.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.relative_to(out).as_posix())
    (out/'SHA256SUMS').write_text('\n'.join(sums)+'\n')
    print(json.dumps({'skills_validated':len(folders),'helper_tests_passed':len(tests),
                      'archives_verified':len(folders)+1,'reviewed_posts':33},ensure_ascii=False))


if __name__=='__main__':
    main()
