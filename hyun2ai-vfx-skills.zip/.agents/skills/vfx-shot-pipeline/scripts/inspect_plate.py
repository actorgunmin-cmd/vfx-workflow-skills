#!/usr/bin/env python3
"""Read plate metadata with ffprobe. Does not install tools or modify the input."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def inspect(path):
    plate = Path(path).expanduser().resolve()
    if not plate.is_file():
        raise ValueError('Input file does not exist: ' + str(plate))
    tools = {name: shutil.which(name) for name in ('ffprobe', 'ffmpeg', 'colmap', 'blender')}
    result = {'plate': str(plate), 'tools': tools, 'metadata': None}
    if not tools['ffprobe']:
        result['status'] = 'ffprobe_missing'
        return result
    proc = subprocess.run([tools['ffprobe'], '-v', 'error', '-show_format', '-show_streams',
                           '-of', 'json', str(plate)], capture_output=True, text=True, timeout=60)
    if proc.returncode:
        raise ValueError('ffprobe failed: ' + proc.stderr.strip())
    result['metadata'] = json.loads(proc.stdout)
    result['status'] = 'metadata_read'
    result['note'] = ('avg_frame_rate and r_frame_rate alone do not prove CFR. '
                      'Inspect per-frame PTS before any frame-rate conversion.')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plate')
    parser.add_argument('--output', help='New JSON path; an existing file is not overwritten.')
    args = parser.parse_args()
    try:
        result = inspect(args.plate)
        payload = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
        if args.output:
            with open(args.output, 'x', encoding='utf-8') as stream:
                stream.write(payload)
        else:
            print(payload, end='')
        return 0 if result['status'] == 'metadata_read' else 2
    except (ValueError, OSError, subprocess.TimeoutExpired) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
