#!/usr/bin/env python3
"""Over-composite straight SDR sRGB RGB + separate alpha in linear light. OpenCV/NumPy."""
import argparse
from pathlib import Path
import sys
import cv2
import numpy as np


def to_linear(value):
    return np.where(value <= .04045, value/12.92, ((value+.055)/1.055)**2.4)


def to_srgb(value):
    return np.where(value <= .0031308, value*12.92, 1.055*np.maximum(value, 0)**(1/2.4)-.055)


def read(path, channels):
    value = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if value is None or value.dtype not in (np.uint8, np.uint16):
        raise ValueError('Use 8/16-bit PNG input: ' + str(path))
    if (channels == 1 and value.ndim != 2) or (channels == 3 and (value.ndim != 3 or value.shape[2] != 3)):
        raise ValueError('Use RGB without alpha, and a separate grayscale alpha')
    return value.astype(np.float32)/np.iinfo(value.dtype).max


def composite(foreground, background, alpha):
    if foreground.shape != background.shape or alpha.shape != foreground.shape[:2]:
        raise ValueError('All inputs must share the original frame dimensions')
    if not all(np.isfinite(v).all() and np.all((v >= 0) & (v <= 1)) for v in (foreground, background, alpha)):
        raise ValueError('Inputs must be finite normalized [0,1] arrays')
    a = alpha[..., None]
    return np.clip(to_srgb(to_linear(foreground)*a+to_linear(background)*(1-a)), 0, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('foreground', 'background', 'alpha', 'output'):
        parser.add_argument('--'+name, required=True)
    args = parser.parse_args()
    try:
        target = Path(args.output)
        if target.exists() or target.suffix.lower() != '.png':
            raise ValueError('Choose a new PNG output path')
        result = composite(read(args.foreground, 3), read(args.background, 3), read(args.alpha, 1))
        if not cv2.imwrite(str(target), np.round(result*65535).astype(np.uint16)):
            raise ValueError('Output write failed')
        print('Wrote linear-light over as 16-bit sRGB PNG; no matting, decontamination or alignment performed.')
        return 0
    except (ValueError, OSError, cv2.error) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
