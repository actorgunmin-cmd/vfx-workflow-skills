#!/usr/bin/env python3
"""Fit/apply a fixed BGR gain/offset to SDR sRGB PNGs; not a Log/HDR grading system."""
import argparse
import json
from pathlib import Path
import sys
import cv2
import numpy as np


def image(path):
    value = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if value is None or value.ndim != 3 or value.shape[2] != 3 or value.dtype not in (np.uint8, np.uint16):
        raise ValueError('Use three-channel 8/16-bit SDR sRGB images, without alpha')
    return value.astype(np.float32)/np.iinfo(value.dtype).max


def pixels(value, mask_path):
    mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
    if mask is None or mask.shape != value.shape[:2]:
        raise ValueError('Mask dimensions must match the corresponding image')
    selected = value[mask > 127]
    if len(selected) < 64:
        raise ValueError('Need at least 64 trusted pixels per mask')
    return selected


def fit(reference_pixels, moving_pixels):
    ref = np.percentile(reference_pixels, [10, 50, 90], axis=0)
    mov = np.percentile(moving_pixels, [10, 50, 90], axis=0)
    span = mov[2]-mov[0]
    if np.any(span < .01) or np.any(ref[2]-ref[0] < .01):
        raise ValueError('Insufficient tonal range in trusted patches')
    gain = (ref[2]-ref[0])/span
    offset = ref[1]-gain*mov[1]
    if np.any(gain < .25) or np.any(gain > 4) or np.any(np.abs(offset) > .5):
        raise ValueError('Extreme grade; verify color encoding, masks and reference')
    return dict(schema=1, encoding='sRGB SDR display-referred', channels='BGR',
                gain=gain.tolist(), offset=offset.tolist(),
                limits='Fixed quantile gain/offset only. No gamut mapping, relighting, temporal fitting or texture matching.')


def apply(value, grade):
    if grade.get('schema') != 1 or grade.get('encoding') != 'sRGB SDR display-referred' or grade.get('channels') != 'BGR':
        raise ValueError('Unsupported grade schema or encoding')
    gain, offset = np.array(grade['gain']), np.array(grade['offset'])
    if gain.shape != (3,) or offset.shape != (3,) or not np.isfinite([gain, offset]).all():
        raise ValueError('Invalid gain/offset')
    raw = value*gain+offset
    return np.clip(raw, 0, 1), float(np.mean((raw < 0) | (raw > 1)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--moving', required=True)
    parser.add_argument('--output', required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--fit', help='New fixed grade JSON')
    group.add_argument('--apply', help='Existing grade JSON; reuse for the shot')
    parser.add_argument('--reference')
    parser.add_argument('--reference-mask')
    parser.add_argument('--moving-mask')
    args = parser.parse_args()
    try:
        target = Path(args.output)
        outputs = [target] + ([Path(args.fit)] if args.fit else [])
        if len({p.resolve() for p in outputs}) != len(outputs) or any(p.exists() for p in outputs):
            raise ValueError('Use distinct new output paths')
        if target.suffix.lower() != '.png':
            raise ValueError('Output must be lossless PNG')
        moving = image(args.moving)
        if args.fit:
            if not all((args.reference, args.reference_mask, args.moving_mask)):
                raise ValueError('--fit requires reference and both trusted masks')
            grade = fit(pixels(image(args.reference), args.reference_mask), pixels(moving, args.moving_mask))
        else:
            grade = json.loads(Path(args.apply).read_text(encoding='utf-8'))
        result, clipped = apply(moving, grade)
        if not cv2.imwrite(str(target), np.round(result*65535).astype(np.uint16)):
            raise ValueError('Output write failed')
        if args.fit:
            Path(args.fit).write_text(json.dumps(grade, indent=2)+'\n', encoding='utf-8')
        print(json.dumps(dict(clipped_channel_fraction=clipped, grade=grade)))
        return 0
    except (ValueError, OSError, KeyError, TypeError, cv2.error) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
